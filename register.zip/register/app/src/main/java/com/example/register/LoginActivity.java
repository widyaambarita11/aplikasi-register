package com.example.register;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private static final String URL_LOGIN =
            "https://ahanbilly.cu.ma/login_app/api_login.php";

    private EditText etUsername;
    private EditText etPassword;

    private Button btnLogin;

    private ProgressBar progressBar;

    private TextView tvDaftar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        btnLogin = findViewById(R.id.btnLogin);

        progressBar = findViewById(R.id.progressBar);

        tvDaftar = findViewById(R.id.tvDaftar);

        btnLogin.setOnClickListener(
                v -> loginUser()
        );

        tvDaftar.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            LoginActivity.this,
                            RegisterActivity.class
                    );

            startActivity(intent);
        });
    }

    private void loginUser() {

        final String username =
                etUsername.getText()
                        .toString()
                        .trim();

        final String password =
                etPassword.getText()
                        .toString()
                        .trim();

        if (username.isEmpty() ||
                password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Isi semua field!",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        progressBar.setVisibility(
                View.VISIBLE
        );

        btnLogin.setEnabled(false);

        StringRequest request =
                new StringRequest(
                        Request.Method.POST,
                        URL_LOGIN,

                        response -> {

                            progressBar.setVisibility(
                                    View.GONE
                            );

                            btnLogin.setEnabled(true);

                            try {

                                JSONObject json =
                                        new JSONObject(response);

                                boolean success =
                                        json.getBoolean("success");

                                String message =
                                        json.getString("message");

                                if (success) {

                                    JSONObject user =
                                            json.getJSONObject("user");

                                    String uname =
                                            user.getString("username");

                                    Toast.makeText(
                                            this,
                                            "Selamat datang, "
                                                    + uname,
                                            Toast.LENGTH_LONG
                                    ).show();

                                    Intent intent =
                                            new Intent(
                                                    LoginActivity.this,
                                                    MainActivity.class
                                            );

                                    intent.putExtra(
                                            "username",
                                            uname
                                    );

                                    startActivity(intent);

                                    finish();

                                } else {

                                    Toast.makeText(
                                            this,
                                            message,
                                            Toast.LENGTH_SHORT
                                    ).show();
                                }

                            } catch (Exception e) {

                                Toast.makeText(
                                        this,
                                        "Error parsing: "
                                                + e.getMessage(),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        },

                        error -> {

                            progressBar.setVisibility(
                                    View.GONE
                            );

                            btnLogin.setEnabled(true);

                            String errorMessage;

                            if (error.networkResponse != null) {

                                errorMessage =
                                        "HTTP "
                                                + error.networkResponse.statusCode;

                            } else if (error.getMessage() != null) {

                                errorMessage =
                                        error.getMessage();

                            } else {

                                errorMessage =
                                        error.toString();
                            }

                            Toast.makeText(
                                    this,
                                    "Koneksi gagal: "
                                            + errorMessage,
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                ) {

                    @Override
                    protected Map<String, String>
                    getParams() {

                        Map<String, String> params =
                                new HashMap<>();

                        params.put(
                                "username",
                                username
                        );

                        params.put(
                                "password",
                                password
                        );

                        return params;
                    }
                };

        Volley
                .newRequestQueue(this)
                .add(request);
    }
}